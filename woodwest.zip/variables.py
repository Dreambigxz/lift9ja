import time
import requests
from django.shortcuts import render, redirect
from django.http import HttpRequest, HttpResponseRedirect
from django.views.generic import (View, TemplateView, ListView, DetailView)
from django.contrib.auth.mixins import LoginRequiredMixin
from django.conf import settings
from django.core.paginator import Paginator
from datetime import datetime, timedelta, date, time
import datetime
import json
from django.contrib.sites.shortcuts import get_current_site
from django.template import loader
from django.utils import timezone
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import F
from mailjet_rest import Client
from user.token_generator import account_number_generator, otp_Verification
from django.contrib.auth.decorators import login_required
from django.template import loader
from django.contrib.auth import update_session_auth_hash
from django.core.mail import send_mail
from uuid import getnode as get_mac
from user.generate_password import generated_password
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib.auth import authenticate, login, logout
from notification import notifications, alert_group_notification
from django.db.models import Q
from referral.models import UserReferral
from django.views.decorators.http import require_POST, require_GET
from django.views.decorators.csrf import csrf_exempt
from user.token_generator import account_activation_token
from percent_calculator import percentage_calculator
from userwallet.deposit_id import deposit_id
from decimal import Decimal
from userwallet.flutter_wave_deposit_api import transfer_deposit, deposit_api, withdraw, verify_transanction
from user.models import (MyUser, UserPreference,
                         PersonalInfomation, ContactUs,
                         TESTIMONIA)
from peektopapp.models import (Packages, Shares,
                               Post, Activities)
from userwallet.models import (WithdrawPin, UserWallet,
                               WalletHistory, WithdrawReview)
from myadmin.models import Administration, AdminBank
from transaction_id import get_transaction_id
from transaction_id import get_transaction_id
import socket
import json
import random
import pickle
from pickle_load import *
from notification import *

current_timezone = timezone.now() + timedelta(hours=1)
api_key = settings.MAIL_JET_API_KEY
api_secret = settings.MAIL_JET_API_SECRET_KEY
mailjet = Client(auth=(api_key, api_secret), version='v3.1')
COMPANY = 'Woodwest'

success = '✓'
login_id = '1907528152:AAFKUHxZAUH64cbNPvlw3OPL2vocRTg0e7g'
contact_id = '1962953232:AAFCTi6qZl3LiguWshfgUnHjHzdJewsR3CA'

greg = 1913121780
yusuf = 1799480324
dan = 1913121780

general_group = 'peektopmobiletd'
# general_group = 'masterminds002'
support = 'masterminds002'
bot_id = '2025605793:AAEjftnjpSZn7vo4kDZ1nPahqguGimdndyE'

web_logins_bot = '2050752630:AAEOGwpb9k0KBdT8qF0EUhnbLlexMjx9PzY'
web_login_page = '-621761649'

today = datetime.datetime.today()

try:
    admin = Administration.objects.get(user__email='donyemordi@gmail.com')
except:
    admin = ''

minimum = 1000
minimum_withdrawal = 5000
maximum = 700000
file_name = 'coupons/coupon_codes'
site_name = 'Woodwest Limited'
